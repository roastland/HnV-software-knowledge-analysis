package com.fsck.k9.mail.store.imap;


public class ImapResponseParserException extends RuntimeException {
    public ImapResponseParserException(String message, Throwable cause) {
        super(message, cause);
    }
}
