# Solitaire
Implementation of the Solitaire card game with JavaFX 

Demonstration application for my software development course at McGill University (COMP 303).
