/*
 * @(#)HJDError.java 5.1
 *
 */

package CH.ifa.draw.framework;

/**
 * A HJD Error.
 *
 */
public class HJDError extends Error {

    public HJDError(String msg) {
	    super(msg);
    }
}
